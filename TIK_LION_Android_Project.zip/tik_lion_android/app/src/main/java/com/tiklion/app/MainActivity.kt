package com.tiklion.app

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URL

private val Blue = Color(0xFF1769D2)
private val PaleBlue = Color(0xFFF0F6FF)
private val Ink = Color(0xFF17365D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TikLionScreen() }
    }
}

@Composable
fun TikLionScreen() {
    val context = LocalContext.current
    var link by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("ألصق رابط فيديو تملكه أو لديك إذن بتنزيله") }

    MaterialTheme {
        Surface(color = PaleBlue, modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(18.dp))
                Text("🦁", fontSize = 54.sp)
                Text("TIK LION", color = Blue, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("نزّل واحفظ مقاطعك بسهولة", color = Ink, fontSize = 15.sp)
                Spacer(Modifier.height(28.dp))
                Card(
                    backgroundColor = Color.White,
                    shape = RoundedCornerShape(24.dp),
                    elevation = 5.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Text("رابط الفيديو", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = link,
                            onValueChange = { link = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("https://...") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                            shape = RoundedCornerShape(14.dp)
                        )
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = {
                                val cleaned = link.trim()
                                if (!cleaned.startsWith("https://") && !cleaned.startsWith("http://")) {
                                    status = "أدخل رابطاً صحيحاً يبدأ بـ https://"
                                } else if (cleaned.contains("tiktok.com", ignoreCase = true)) {
                                    openTikTok(context, cleaned)
                                    status = "فتحنا رابط TikTok. استخدم خيار الحفظ الرسمي أو نزّل نسختك الأصلية."
                                } else {
                                    downloadDirectVideo(context, cleaned) { result -> status = result }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            colors = ButtonDefaults.buttonColors(backgroundColor = Blue, contentColor = Color.White),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("متابعة / تنزيل", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(status, color = Ink, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                }
                Spacer(Modifier.height(22.dp))
                InfoCard("طريقة الاستخدام", "1. انسخ رابط المقطع.\n2. الصقه هنا.\n3. إذا كان رابط TikTok، افتحه واستخدم خيارات الحفظ المتاحة من صاحب المقطع.")
                Spacer(Modifier.height(12.dp))
                InfoCard("تنزيل ملف فيديو مباشر", "يمكن للتطبيق تنزيل رابط ملف فيديو مباشر بصيغة MP4 عندما يكون متاحاً ومصرحاً لك بحفظه.")
                Spacer(Modifier.height(18.dp))
                Text("TIK LION • الإصدار 1.0", color = Color(0xFF6C83A2), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(backgroundColor = Color.White, shape = RoundedCornerShape(18.dp), elevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Blue, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(body, color = Ink, fontSize = 13.sp, lineHeight = 20.sp)
        }
    }
}

private fun openTikTok(context: Context, link: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
    } catch (_: Exception) {
        Toast.makeText(context, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show()
    }
}

private fun downloadDirectVideo(context: Context, link: String, report: (String) -> Unit) {
    try {
        val parsed = URL(link)
        if (!parsed.path.lowercase().endsWith(".mp4")) {
            report("هذا ليس رابط MP4 مباشراً. روابط صفحات المواقع لا تُنزّل بهذه الطريقة.")
            return
        }
        val request = DownloadManager.Request(Uri.parse(link))
            .setTitle("TIK LION video")
            .setDescription("جارٍ تنزيل الفيديو")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_MOVIES, "TikLion_${System.currentTimeMillis()}.mp4")
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
        report("بدأ التنزيل. ستجد الفيديو في مجلد Movies بعد اكتماله.")
    } catch (_: Exception) {
        report("تعذر بدء التنزيل. تحقق من الرابط واتصال الإنترنت.")
    }
}
